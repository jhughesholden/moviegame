# 🎬 Moviedle

A movie guessing game with a vintage cinema theme. Guess the secret film in 8 tries — after each wrong guess you'll get clues about the director, cast, studio, genre, and release year.

## Running locally

Make sure you have [Node.js](https://nodejs.org) installed (v18 or later).

```bash
# Install dependencies
npm install

# Start the dev server
npm run dev
```

Then open [http://localhost:5173](http://localhost:5173) in your browser.

## Deploying to Vercel (free)

1. Push this repo to GitHub
2. Go to [vercel.com](https://vercel.com) and sign in with GitHub
3. Click **Add New Project** and import your repo
4. Leave all settings as default and click **Deploy**

That's it — Vercel auto-detects Vite and deploys it live with a public URL.

## Notes

- The game uses the [Anthropic API](https://anthropic.com) to pick movies and evaluate guesses. The API key is handled automatically when running inside Claude.ai. If you deploy it elsewhere, you'll need to add your own key.
